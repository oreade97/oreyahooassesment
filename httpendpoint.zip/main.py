from flask import Flask, jsonify, request
from google.cloud import storage
import datetime
import json
import logging
import os

app = Flask(__name__)

# Define a dictionary to store the request timestamps for rate limiting
request_timestamps = {}

# Set the rate limit to 210 requests per 10 minutes
REQUEST_LIMIT = 210
TIME_LIMIT = 600  # 10 minutes in seconds

@app.route('/')
def get_last_object_content(request):
    bucket_name = os.environ.get("BUCKET_NAME")
    if not bucket_name:
        return jsonify({"error": "BUCKET_NAME environment variable not set"}), 500

    # Get the IP address of the requester
    remote_ip = request.remote_addr

    # Check if the IP address has exceeded the rate limit
    if not is_request_allowed(remote_ip):
        return jsonify({"error": "Rate limit exceeded"}), 429

    last_object_name = get_last_object(bucket_name)
    if last_object_name:
        content = get_object_content(bucket_name, last_object_name)
        return jsonify(content)
    else:
        return jsonify({"error": "No objects found in the bucket"})

def get_last_object(bucket_name):
    storage_client = storage.Client()
    bucket = storage_client.bucket(bucket_name)

    # List blobs in the bucket
    blobs = bucket.list_blobs()

    # Sort blobs by modification time
    sorted_blobs = sorted(blobs, key=lambda x: x.updated, reverse=True)

    if sorted_blobs:
        # Get the first (latest) blob
        last_blob = sorted_blobs[0]
        return last_blob.name
    else:
        return None

def get_object_content(bucket_name, object_name):
    storage_client = storage.Client()
    bucket = storage_client.bucket(bucket_name)
    blob = bucket.blob(object_name)

    # Download content from the blob
    content = blob.download_as_text()
    return content

def is_request_allowed(ip_address):
    # Check if the IP address has made fewer than REQUEST_LIMIT requests in the last TIME_LIMIT seconds
    now = datetime.datetime.now().timestamp()
    timestamps = request_timestamps.get(ip_address, [])
    timestamps = [timestamp for timestamp in timestamps if now - timestamp <= TIME_LIMIT]

    if len(timestamps) < REQUEST_LIMIT:
        timestamps.append(now)
        request_timestamps[ip_address] = timestamps
        return True
    else:
        return False

def log_rate_limit_exceeded_message(ip_address):
    # Log a message indicating rate limit exceeded
    log_name = "rate-limit-exceeded"
    logger = logging_client.logger(log_name)
    log_entry = logger.log_text(f"Rate limit exceeded for IP address: {ip_address}")
    logger.log_struct(
        {"ip_address": ip_address},
        severity="ERROR",
    )

if __name__ == '__main__':
    app.run(debug=True, host='0.0.0.0', port=8080)
