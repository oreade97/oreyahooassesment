from google.cloud import storage
import datetime
import os

def write_to_blob(bucket_name):
    # Get the current timestamp
    current_time = datetime.datetime.now().strftime("%d-%b-%Y (%H:%M:%S.%f)")
    # Create a new filename with timestamp
    new_file_name = f"object_{current_time}.txt"
    storage_client = storage.Client()
    bucket = storage_client.bucket(bucket_name)
    blob = bucket.blob(new_file_name)
    # Upload content to the new object
    blob.upload_from_string(current_time)
    print(f"New object created: {new_file_name}")

# Change to name of Pub/Sub topic created
def hello_pubsub(event, context):
    """Triggered from a message on a Cloud Pub/Sub topic.
    Args:
        event (dict): Event payload.
        context (google.cloud.functions.Context): Metadata for the event.
    """
    # The function will be triggered with each call, creating a new object
    bucket_name = os.environ.get("BUCKET_NAME")
    if not bucket_name:
        print("Error: BUCKET_NAME environment variable not set.")
        return

    write_to_blob(bucket_name)
